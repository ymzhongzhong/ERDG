function MyRun()
    warning('off');
    global D001  imbalanceLevel001 benchmarkName001 i003 func i004 filePaths;
    benchmarkName = {'LargeScaleCEC2010Benchmark'};
    
    filePaths = {'D:\WorkDir\ERDG\LargeScaleCEC2010Benchmark\GroupResult'};
    
    for i002 = 1 : numel(benchmarkName)
        benchmarkName001 = benchmarkName{i002};                    
        if strcmp(benchmarkName001, 'LargeScaleCEC2010Benchmark') == 1
            D = [1000:1000:5000];
            imbalanceLevel = {'1'};
        elseif strcmp(benchmarkName001, 'LargeScaleCEC2013Benchmark') == 1
            D = 1000;
            imbalanceLevel = {'1'};
        end
        for i001 = 1 : numel(D)
            D001 = D(i001);
            for i003 = 1 : numel(filePaths)
                for i004 = 1 : numel(imbalanceLevel)
                    imbalanceLevel001 = '';
                    if strcmp(benchmarkName001, 'LargeScaleCEC2010Benchmark') == 1
                        %imbalanceLevel001 = strcat('Imbalance', imbalanceLevel{i004});
                    end
                    if strcmp(benchmarkName001, 'LargeScaleCEC2013Benchmark')
                        func = [1:15];
                    elseif strcmp(benchmarkName001, 'LargeScaleCEC2010Benchmark')
                        func = [1:20];
                    end
                    filePath = fullfile(filePaths{i003}, imbalanceLevel001);
                    fprintf('%s\n', [filePath ' ' num2str(D001)]);
                    GroupResultAnalyze(benchmarkName001, D001, func, filePath);
                end
            end
        end
    end
    
end