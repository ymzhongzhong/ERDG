function GroupResultAnalyze(benchmarkName, D, func, groupFilePath)
    
    dim = D;
    funcN = numel(func);

    non_sepVarsN_rightPerc = zeros(funcN,1);
    non_sepVarsN_right = zeros(funcN ,1);
    non_sepGN_right = zeros(funcN,1);
    non_sepGN_formed = zeros(funcN,1);
    non_sepVarsN_formed = zeros(funcN,1);
    sepVarsN_rightPerc = zeros(funcN, 1);
    sepVarsN_right = zeros(funcN,1);
    sepGN_right = zeros(funcN,1);
    sepGN_formed = zeros(funcN,1);
    sepVarsN_formed = zeros(funcN,1);
    fEvalNum001 = zeros(funcN,1);
    

     for funcIndex = 1 : funcN
         func_num = func(funcIndex);
         FilePath = strcat('F:\RecentWork\LSO\Decomposition\IRDG\Code\',benchmarkName);            
        if strcmp(benchmarkName, 'LargeScaleCEC2010Benchmark')            
            if dim == 1000
                probFile = strcat(FilePath, '/datafile/f', num2str(func_num,'%02d'), '.mat');
                if ~exist(probFile, 'file')
                    probFile = strcat(FilePath, '/datafiles/f', num2str(func_num,'%02d'), '_o.mat');
                end
                if ~exist(probFile, 'file')
                    probFile = strcat(FilePath, '/datafiles/f', num2str(func_num,'%02d'), '_opm.mat');
                end
                if ~exist(probFile, 'file')
                    probFile = strcat(FilePath, '/datafiles/f', num2str(func_num,'%02d'), '_op.mat');
                end
            else
                probFile = strcat(FilePath, '/datafile/f', num2str(func_num,'%02d'), '_', num2str(dim), '.mat');
                if ~exist(probFile, 'file')
                    probFile = strcat(FilePath, '/datafiles/f', num2str(func_num,'%02d'), '_o_', num2str(dim), '.mat');
                end
                if ~exist(probFile, 'file')
                    probFile = strcat(FilePath, '/datafiles/f', num2str(func_num,'%02d'), '_opM_', num2str(dim), '.mat');
                end
                if ~exist(probFile, 'file')
                    probFile = strcat(FilePath, '/datafiles/f', num2str(func_num,'%02d'), '_op_', num2str(dim), '.mat');
                end
            end
            
            m = 50;
            if ismember(func_num, [1:3])
                D = dim;
                p = [1:D];
                prob_non_sepGN = 0;
                prob_sepGN = D;
            elseif ismember(func_num, [4:8])
                D = dim;
                load(probFile, '-mat', 'p');
                prob_non_sepGN = 1;
                prob_sepGN = D - prob_non_sepGN*m;
            elseif ismember(func_num, [9:13])
                D = dim;
                load(probFile, '-mat', 'p');
                prob_non_sepGN = D/m/2;
                prob_sepGN = D - prob_non_sepGN*m;
            elseif ismember(func_num, [14:18])
                D = dim;
                load(probFile, '-mat', 'p');
                prob_non_sepGN = D/m;
                prob_sepGN = D - prob_non_sepGN*m;
            elseif ismember(func_num, [19:20])
                D = dim;
                m = D;
                p = [1:D];                
                prob_non_sepGN = 1;
                prob_sepGN = 0;
            end
            
            prob_groupsN = prob_non_sepGN + prob_sepGN;
            prob_groups = cell(prob_groupsN, 1);
            start_p = 0;
            end_p = 0;
            for index = 1 : prob_non_sepGN
                start_p = (index-1) * m + 1;
                end_p = index * m;
                prob_groups(index) = {p(start_p : end_p)};
            end
            for index = 1 : prob_sepGN
                prob_groups(index+prob_non_sepGN) = {p(index+end_p)};
            end       
            
        end
        
        if strcmp(benchmarkName, 'LargeScaleCEC2013Benchmark')
            probFile = strcat(FilePath, '/datafiles/f', num2str(func_num,'%02d'), '.mat');            
            if ismember(func_num, [1:3])
                D = dim;
                p = [1:D];
                s = [];
                prob_non_sepGN = 0;
                prob_sepGN = D;
            elseif ismember(func_num, [4:7])
                D = dim;
                load(probFile, '-mat', 'p', 's');
                prob_non_sepGN = 7;
                prob_sepGN = D - sum(s);
            elseif ismember(func_num, [8:11])
                D = dim;
                load(probFile, '-mat', 'p', 's');
                prob_non_sepGN = 20;
                prob_sepGN = D - sum(s);
            elseif ismember(func_num, [12,15])
                D = dim;
                p = [1:D];
                s = D;
                prob_non_sepGN = 1;
                prob_sepGN = 0;
            elseif ismember(func_num, [13:14])
                load(probFile, '-mat', 'p', 's', 'm');
                prob_non_sepGN = 1;
                D = sum(s)-(m*(size(s,1)-1));
                s = D;
                prob_sepGN = 0;
            end
            
            prob_groupsN = prob_non_sepGN + prob_sepGN;
            prob_groups = cell(prob_groupsN, 1);
            start_p = 0;
            end_p = 0;
            for index = 1 : prob_non_sepGN
                if index == 1
                    start_p = 1;
                    end_p = s(index);
                else
                    start_p = end_p + 1;
                    end_p = start_p + s(index) - 1;
                end
                prob_groups(index) = {p(start_p : end_p)};
            end
            for index = 1 : prob_sepGN
                prob_groups(index+prob_non_sepGN) = {p(index+end_p)};
            end            
        end
        groupFile = fullfile(groupFilePath,strcat('f',num2str(func_num), '_groups', '_D', num2str(D), '.mat')); 
        [pathstr,name,ext] = fileparts(groupFile);
        rightPercFile =  fullfile(pathstr, strcat('rightPerc_D', num2str(D), '.mat'));
        
        load(groupFile, '-mat', 'groups','fEvalNum');	
        
%         %%%%%%%%%%%
%         load(probFile, '-mat', 'p', 's', 'm');
%         c = 0;
%         for i = 1 : numel(s)
%             c0 = c;
%             c = c0 + s(i);
%             startp = c0 - (i-1) * m +1;
%             endp = c - (i-1) * m;
%             a001 = p(startp : endp);
%             if ~all(ismember(a001, groups{1})) && ~all(ismember(a001, groups{2}))
%                 disp(i);            
%             end
%         end
%         %%%%%%%%%%%%%%
        
        
        fEvalNum001(funcIndex,1) = fEvalNum;
        
        
        [prob_non_sepGN, prob_non_sepVarsN, prob_sepGN, prob_sepVarsN] = GetNonSepAndSepInfo(prob_groups);
        for index = 1 : numel(prob_groups)
            for index001 = 1 : numel(groups)
                if numel(groups{index001})==numel(prob_groups{index})
                    if isempty(setdiff(groups{index001}, prob_groups{index}))
                        if numel(groups{index001})>1
                            non_sepGN_right(funcIndex,1) = non_sepGN_right(funcIndex,1) + 1;
                            non_sepVarsN_right(funcIndex,1) = non_sepVarsN_right(funcIndex,1) + numel(groups{index001});
                        elseif numel(groups{index001})==1
                            sepGN_right(funcIndex,1) = sepGN_right(funcIndex,1) + 1;
                            sepVarsN_right(funcIndex,1) = sepVarsN_right(funcIndex,1) + 1;
                        end
                        break;
                    end
                end
            end
        end
        
        if prob_non_sepVarsN==0
            non_sepVarsN_rightPerc(funcIndex,1) = nan;
            non_sepGN_right(funcIndex,1) = nan;
            non_sepVarsN_right(funcIndex,1) = nan;
        else 
            non_sepVarsN_rightPerc(funcIndex,1) = non_sepVarsN_right(funcIndex,1) / prob_non_sepVarsN;
        end
        
        if prob_sepVarsN==0
            sepVarsN_rightPerc(funcIndex,1) = nan;
            sepVarsN_right(funcIndex,1) = nan;
            sepGN_right(funcIndex,1) = nan;
        else
            sepVarsN_rightPerc(funcIndex,1) = sepVarsN_right(funcIndex,1) / prob_sepVarsN;
        end
        
        [non_sepGN_formed(funcIndex,1), non_sepVarsN_formed(funcIndex,1), sepGN_formed(funcIndex,1), sepVarsN_formed(funcIndex,1)] = GetNonSepAndSepInfo(groups);
    end
    
    save(rightPercFile, 'non_sepGN_right', 'non_sepVarsN_right', 'sepGN_right', 'sepVarsN_right' , 'non_sepVarsN_rightPerc', ...
        'sepVarsN_rightPerc', 'non_sepGN_formed', 'non_sepVarsN_formed', 'sepGN_formed', 'sepVarsN_formed', 'fEvalNum001', '-mat');  
    
    Write2Xlsx(fEvalNum001, sepVarsN_rightPerc, non_sepVarsN_rightPerc);
end

function [non_sepGN, non_sepVarsN, sepGN, sepVarsN] = GetNonSepAndSepInfo(groups)
    non_sepGN = 0; non_sepVarsN = 0; sepGN = 0; sepVarsN = 0;
    for index = 1 : numel(groups)
        if numel(groups{index})==1
            sepGN = sepGN + 1;
        elseif numel(groups{index})>1
            non_sepGN = non_sepGN + 1;
            non_sepVarsN = non_sepVarsN + numel(groups{index});
        end
    end
    sepVarsN = sepGN;
end

function Write2Xlsx(fEvalNum001, sepVarsN_rightPerc, non_sepVarsN_rightPerc)
    global D001  imbalanceLevel001 benchmarkName001 i003 func i004;
    
    if strcmp(benchmarkName001, 'LargeScaleCEC2013Benchmark')
        probName = 'cec2013';
    elseif strcmp(benchmarkName001, 'LargeScaleCEC2010Benchmark')
        probName = 'cec2010';
    end
    fileName = 'GroupResult20190517.xlsx';
    sheetname = strcat(probName, 'D', num2str(D001));
    
    rowLable001 = num2str(1 + (i004-1) * (numel(func)+2));
    rowLable002 = num2str(str2num(rowLable001) + numel(func) -1);
                
    columnLable = char(uint8('A') + (i003-1) * 3);
    xlsRange = strcat(columnLable, rowLable001, ':', columnLable, rowLable002);
    xlswrite(fileName,fEvalNum001,sheetname, xlsRange);
    columnLable = char(uint8('A') + (i003-1) * 3+1);
    xlsRange = strcat(columnLable, rowLable001, ':', columnLable, rowLable002);
    xlswrite(fileName,sepVarsN_rightPerc,sheetname,xlsRange);
    columnLable = char(uint8('A') + (i003-1) * 3+2);
    xlsRange = strcat(columnLable, rowLable001, ':', columnLable, rowLable002);
    xlswrite(fileName,non_sepVarsN_rightPerc,sheetname,xlsRange);
end